import controllers.TetrisController;
public class Tetris{

    public Tetris() {

    }

    public static void main(String[] args){
        new TetrisController(); // call a controller to start a game
    }
}